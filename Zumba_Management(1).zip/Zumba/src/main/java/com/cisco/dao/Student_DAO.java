package com.cisco.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cisco.dbutil.DbUtil;
import com.cisco.pojo.Student;

public class Student_DAO {

    // Register a new User (Create)
    public boolean registerUser(Student user) {
        String sql = "INSERT INTO users (name, phno, emailid, gender, password) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DbUtil.getConn(); 
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, user.getsName());
            stmt.setString(2, user.getPhno());
            stmt.setString(3, user.getEmailid());
            stmt.setString(4, user.getGender());
            stmt.setString(5, user.getPassword());

            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0; // If rows affected > 0, registration was successful

        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Validate User Login (Check if email and password are correct)
    public boolean validateLogin(String emailid, String password) {
        String sql = "SELECT * FROM users WHERE emailid = ? AND password = ?";
        try (Connection conn = DbUtil.getConn(); 
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, emailid);
            stmt.setString(2, password);

            ResultSet rs = stmt.executeQuery();
            return rs.next(); // Returns true if a match is found

        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            return false;
        }
    }
}
