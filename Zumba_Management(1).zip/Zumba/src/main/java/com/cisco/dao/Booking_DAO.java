package com.cisco.dao;

import java.sql.*;

public class Booking_DAO {
    private Connection connection;

    public Booking_DAO() {
        try {
            this.connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/db9", "user", "root");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to book a trainer slot
    public boolean bookTrainer(String userEmail, String trainerEmail, Date slotDate) {
        String query = "INSERT INTO bookings (user_email, trainer_email) VALUES (?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, userEmail);
            stmt.setString(2, trainerEmail);
           
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
