

package com.cisco.dbutil;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DbUtil {
    public static Connection getConn() throws ClassNotFoundException, SQLException {
        Class.forName(DbUtilHelperConstant.DRIVER_CLASS);
        return DriverManager.getConnection(
            DbUtilHelperConstant.DB_URL,
            DbUtilHelperConstant.USERNAME,
            DbUtilHelperConstant.PASSWORD
        );
    }
}
