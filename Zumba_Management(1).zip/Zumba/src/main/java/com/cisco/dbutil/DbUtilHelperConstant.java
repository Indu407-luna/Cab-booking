package com.cisco.dbutil;

public class DbUtilHelperConstant {
    public static final String DRIVER_CLASS = "com.mysql.cj.jdbc.Driver";
    public static final String DB_URL = "jdbc:mysql://localhost:3306/db9";
    public static final String USERNAME = "user";
    public static final String PASSWORD = "root";
}


