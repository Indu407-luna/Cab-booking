package com.cisco.pojo;

import java.sql.Date;

public class Booking {

    private int bookingId;     // Unique ID for the booking
    private String userEmail;  // Email of the user who booked
    private String trainerEmail; // Email of the trainer being booked
    private Date slotDate;     // Date of the slot booked

    // Default Constructor
    public Booking() {}

    // Parameterized Constructor
    public Booking(int bookingId, String userEmail, String trainerEmail, Date slotDate) {
        this.bookingId = bookingId;
        this.userEmail = userEmail;
        this.trainerEmail = trainerEmail;
        this.slotDate = slotDate;
    }

    // Getters and Setters
    public int getBookingId() {
        return bookingId;
    }

    public void setBookingId(int bookingId) {
        this.bookingId = bookingId;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public String getTrainerEmail() {
        return trainerEmail;
    }

    public void setTrainerEmail(String trainerEmail) {
        this.trainerEmail = trainerEmail;
    }


   

    // Override toString for Debugging
    @Override
    public String toString() {
        return "Booking [bookingId=" + bookingId + ", userEmail=" + userEmail + 
               ", trainerEmail=" + trainerEmail + "]";
    }
}
