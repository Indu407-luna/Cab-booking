package com.cisco.pojo;

public class Student {
    private String sName;
    private String phno;
    private String emailid;
    private String gender;
    private String password;

    // Getter methods
    public String getsName() {
        return sName;
    }

    public String getPhno() {
        return phno;
    }

    public String getEmailid() {
        return emailid;
    }

    public String getGender() {
        return gender;
    }

    public String getPassword() {
        return password;
    }

    // Setter methods (if needed)
    public void setsName(String sName) {
        this.sName = sName;
    }

    public void setPhno(String phno) {
        this.phno = phno;
    }

    public void setEmailid(String emailid) {
        this.emailid = emailid;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
